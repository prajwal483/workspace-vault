"use client";

const useSecret = (
  workspace: string,
  setHasKeyFoundAlready?: React.Dispatch<React.SetStateAction<boolean>>
) => {
  return null;
};

export default useSecret;
