module.exports = require('ui/postcss.config');
