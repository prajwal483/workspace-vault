"use client";
import { RecoilRoot as StoreProvider } from "recoil";

export default StoreProvider;
