import { environmentFiles } from "database";

export type SecretFiles = typeof environmentFiles.$inferSelect;
