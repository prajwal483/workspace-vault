"use client";

import { RecoilRoot as DashboardStateRoot } from "recoil";

export default DashboardStateRoot;
