import HowItWorks from "@/components/hero/how-it-works";
import React from "react";

const page = () => {
  return <HowItWorks />;
};

export default page;
