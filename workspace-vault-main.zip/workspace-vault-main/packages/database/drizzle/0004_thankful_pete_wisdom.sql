ALTER TABLE "authenticators" ALTER COLUMN "credentialId" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "authenticators" ALTER COLUMN "credentialPublicKey" SET DATA TYPE text;